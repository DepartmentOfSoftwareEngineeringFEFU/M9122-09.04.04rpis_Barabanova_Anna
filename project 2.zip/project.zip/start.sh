#!/bin/sh

if [ "$DATABASE" = "postgres" ]
then
    echo "Waiting for postgres..."

    while ! nc -z $SQL_HOST $SQL_PORT; do
      sleep 0.1
    done

    echo "PostgreSQL started"
fi

ls

. /opt/venv/bin/activate
flask db upgrade
flask create-role Преподаватель teacher True
flask create-role Ученик student
flask create-user teacher@test.com 12345678 teacher
flask create-user student@test.com 87654321 student

exec "$@"