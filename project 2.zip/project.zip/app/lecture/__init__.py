from flask import Blueprint

lecture_bp = Blueprint('lecture', __name__, url_prefix='/lecture')

from app.lecture import routes