from wtforms import HiddenField, StringField, TextAreaField, SubmitField
from wtforms.validators import DataRequired
from flask_wtf import FlaskForm


class CreateLecture(FlaskForm):
    title = StringField('', validators=[DataRequired()], render_kw={"placeholder": "Название лекции"})
    description = TextAreaField('', validators=[DataRequired()], render_kw={"placeholder": "Материал лекции"})
    submit = SubmitField('Создать')


class EditLecture(FlaskForm):
    id = HiddenField()
    title = StringField('', validators=[DataRequired()])
    description = TextAreaField('', validators=[DataRequired()])
    submit = SubmitField('Изменить')


class DeleteLecture(FlaskForm):
    id = HiddenField()
    submit = SubmitField('Удалить')
