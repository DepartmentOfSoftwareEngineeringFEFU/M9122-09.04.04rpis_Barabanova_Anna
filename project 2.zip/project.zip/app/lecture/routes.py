from flask import render_template, redirect, url_for, request
from flask_login import current_user, login_required
from flask_user import roles_required

from app.lecture import lecture_bp
from app.utils.forms import CreateForm, EditForm, DeleteForm
from app import db
from app.models import Lecture
import sqlalchemy as sa


@lecture_bp.route('/', methods=['GET'])
@login_required
def index():
    return render_template(
        f'lecture/base.html', is_admin=current_user.role.is_admin,
        lectures=db.session.scalars(sa.select(Lecture))
        # c_form=CreateLecture(), e_form=EditLecture(), d_form=DeleteLecture()
    )


@lecture_bp.route('/create', methods=['GET', 'POST'])
@login_required
@roles_required('teacher')
def create():
    form = CreateForm()
    if form.validate_on_submit():
        db.session.add(
            Lecture(
                name=form.title.data,
                description=form.description.data
            )
        )
        db.session.commit()
        return redirect(url_for('lecture.index'))
    return render_template(
        f'lecture/create.html', is_admin=current_user.role.is_admin,
        form=form
    )


@lecture_bp.route('/view/<lecture_id>', methods=['GET', 'POST'])
@login_required
def view(lecture_id):
    lecture: Lecture = db.session.scalar(sa.select(Lecture).where(Lecture.id == lecture_id))
    if request.method == 'POST' and not current_user.role.is_admin or not lecture:
        return redirect(url_for('lecture.index'))
    e_form = EditForm()
    d_form = DeleteForm()
    if e_form.validate_on_submit():
        lecture.name = e_form.title.data
        lecture.description = e_form.description.data
        db.session.commit()
        return redirect(url_for('lecture.index'))
    if d_form.validate_on_submit():
        db.session.delete(lecture)
        db.session.commit()
        return redirect(url_for('lecture.index'))
    e_form.title.data = lecture.name
    e_form.description.data = lecture.description
    d_form.id.data = lecture.id
    return render_template(
        f'lecture/single.html', is_admin=current_user.role.is_admin,
        e_form=e_form, d_form=d_form
    )


# @lecture_bp.route('/list', methods=['GET'])
# @login_required
# def lecture():
#     return jsonify(tuple(map(
#         lambda lecture: {'id': lecture.id, 'title': lecture.name, 'content': lecture.description},
#         db.session.scalars(sa.select(Lecture))
#     )))