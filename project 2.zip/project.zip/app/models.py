from app import db
from typing import Optional
import sqlalchemy as sa
import sqlalchemy.orm as so
from flask_user import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash


# Модели


class Lecture(db.Model):
    __tablename__ = 'lecture'

    id: so.Mapped[int] = so.mapped_column(primary_key=True)
    name: so.Mapped[str] = so.mapped_column(sa.String(100), index=True)
    description: so.Mapped[str] = so.mapped_column(sa.TEXT, nullable=True)


class Task(db.Model):
    __tablename__ = 'task'

    id: so.Mapped[int] = so.mapped_column(primary_key=True)
    name: so.Mapped[str] = so.mapped_column(sa.String(100), index=True)
    description: so.Mapped[str] = so.mapped_column(sa.TEXT, nullable=True)


class Test(db.Model):
    __tablename__ = 'test'

    id: so.Mapped[int] = so.mapped_column(primary_key=True)
    name: so.Mapped[str] = so.mapped_column(sa.String(100), index=True)
    description: so.Mapped[str] = so.mapped_column(sa.TEXT, nullable=True)

    def get_solution(self, user):
        for solution in self.user_test_associations:
            if solution.user.id == user.id:
                return solution


class GigaTest(db.Model):
    __tablename__ = 'giga_test'

    id: so.Mapped[int] = so.mapped_column(primary_key=True)
    name: so.Mapped[str] = so.mapped_column(sa.String(100), index=True)
    description: so.Mapped[str] = so.mapped_column(sa.TEXT, nullable=True)

    def get_solution(self, user):
        for solution in self.user_giga_test_associations:
            if solution.user.id == user.id:
                return solution


class UserTestAssociation(db.Model):
    __tablename__ = 'user_test_association'

    user_id: so.Mapped[int] = so.mapped_column(sa.Integer, sa.ForeignKey('user.id'), primary_key=True)
    test_id: so.Mapped[int] = so.mapped_column(sa.Integer, sa.ForeignKey('test.id'), primary_key=True)
    solution: so.Mapped[str] = so.mapped_column(sa.TEXT, nullable=False)
    mark: so.Mapped[int] = so.mapped_column(sa.Integer, nullable=True)

    user = db.relationship('User', backref='user_test_associations')
    test = db.relationship('Test', backref='user_test_associations')


class UserGigaTestAssociation(db.Model):
    __tablename__ = 'user_giga_test_association'

    user_id: so.Mapped[int] = so.mapped_column(sa.Integer, sa.ForeignKey('user.id'), primary_key=True)
    giga_test_id: so.Mapped[int] = so.mapped_column(sa.Integer, sa.ForeignKey('giga_test.id'), primary_key=True)
    solution: so.Mapped[str] = so.mapped_column(sa.TEXT, nullable=False)
    mark: so.Mapped[int] = so.mapped_column(sa.Integer, nullable=True)

    user = db.relationship('User', backref='user_giga_test_associations')
    giga_test = db.relationship('GigaTest', backref='user_giga_test_associations')


class Role(db.Model):
    __tablename__ = 'role'

    id: so.Mapped[int] = so.mapped_column(primary_key=True)
    name: so.Mapped[str] = so.mapped_column(sa.String(64), unique=True)
    label: so.Mapped[str] = so.mapped_column(sa.String(64), unique=True)
    is_admin: so.Mapped[bool] = so.mapped_column(sa.Boolean, default=False, server_default='0')

    def __repr__(self):
        return '<Role {}>'.format(self.label)


class User(UserMixin, db.Model):
    __tablename__ = 'user'

    id: so.Mapped[int] = so.mapped_column(primary_key=True)
    email: so.Mapped[str] = so.mapped_column(sa.String(120), index=True,
                                             unique=True)
    password_hash: so.Mapped[Optional[str]] = so.mapped_column(sa.String(256))
    roles = db.relationship('Role', secondary='user_role',
                            backref=db.backref('users', lazy='dynamic'))

    def __repr__(self):
        return '<User {}>'.format(self.email)

    def has_role(self, role_tag):
        return self.role.tag == role_tag

    def role_name(self):
        if self.role:
            return self.role.name
        else:
            return "No role assigned"

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def password(self):
        return self.password_hash

    @property
    def role(self):
        return self.roles[0]


class UsersRoles(db.Model):
    __tablename__ = 'user_role'
    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), db.ForeignKey('user.id', ondelete='CASCADE'))
    role_id = db.Column(db.Integer(), db.ForeignKey('role.id', ondelete='CASCADE'))
