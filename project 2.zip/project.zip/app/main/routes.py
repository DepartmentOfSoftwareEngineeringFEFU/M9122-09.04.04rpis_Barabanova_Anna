from flask import render_template

from app.main import main_bp
from flask_login import login_required, current_user


@main_bp.route('/', methods=['GET'])
@main_bp.route('/index', methods=['GET'])
@login_required
def index():
    return render_template(f'home/{current_user.role.name}.html', user=current_user, is_admin=current_user.role.is_admin)
