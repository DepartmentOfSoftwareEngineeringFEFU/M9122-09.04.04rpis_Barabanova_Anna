from flask import Blueprint

giga_test_bp = Blueprint('giga_test', __name__, url_prefix='/giga_test')

from app.giga_test import routes
