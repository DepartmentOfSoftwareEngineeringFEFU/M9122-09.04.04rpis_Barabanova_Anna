from flask import render_template, redirect, url_for
from flask_login import current_user, login_required
from flask_user import roles_required

from app.giga_test import giga_test_bp
from app.utils.forms import CreateForm, EditForm, DeleteForm, AnswerForm
from app import db
from app.models import GigaTest, UserGigaTestAssociation
import sqlalchemy as sa


@giga_test_bp.route('/', methods=['GET'])
@login_required
def index():
    return render_template(
        f'giga_test/base.html', is_admin=current_user.role.is_admin,
        giga_tests=db.session.scalars(sa.select(GigaTest)),
        user=current_user
    )


@giga_test_bp.route('/create', methods=['GET', 'POST'])
@login_required
@roles_required('teacher')
def create():
    form = CreateForm()
    if form.validate_on_submit():
        db.session.add(
            GigaTest(
                name=form.title.data,
                description=form.description.data
            )
        )
        db.session.commit()
        return redirect(url_for('giga_test.index'))
    return render_template(
        f'giga_test/create.html', is_admin=current_user.role.is_admin,
        form=form
    )


@giga_test_bp.route('/view/<giga_test_id>', methods=['GET', 'POST'])
@login_required
def view(giga_test_id):
    finished_giga_test = db.session.scalar(
        sa.select(UserGigaTestAssociation)
        .where(
            UserGigaTestAssociation.giga_test_id == giga_test_id,
            UserGigaTestAssociation.user_id == current_user.id
        )
    )
    giga_test: GigaTest = db.session.scalar(sa.select(GigaTest).where(GigaTest.id == giga_test_id))
    if not giga_test or finished_giga_test:
        return redirect(url_for('giga_test.index'))
    e_form = EditForm()
    d_form = DeleteForm()
    s_form = AnswerForm()
    if e_form.validate_on_submit():
        giga_test.name = e_form.title.data
        giga_test.description = e_form.description.data
        db.session.commit()
        return redirect(url_for('giga_test.index'))
    if d_form.validate_on_submit():
        db.session.delete(giga_test)
        db.session.commit()
        return redirect(url_for('giga_test.index'))
    if s_form.validate_on_submit():
        db.session.add(
            UserGigaTestAssociation(
                user=current_user,
                giga_test_id=giga_test_id,
                solution=s_form.solution.data
            )
        )
        db.session.commit()
        return redirect(url_for('giga_test.index'))
    e_form.title.data = giga_test.name
    e_form.description.data = giga_test.description
    d_form.id.data = giga_test.id
    return render_template(
        f'giga_test/single.html', is_admin=current_user.role.is_admin,
        e_form=e_form, d_form=d_form, s_form=s_form
    )


# @giga_test_bp.route('/list', methods=['GET'])
# @login_required
# def giga_test():
#     return jsonify(tuple(map(
#         lambda giga_test: {'id': giga_test.id, 'title': giga_test.name, 'content': giga_test.description},
#         db.session.scalars(sa.select(giga_test))
#     )))