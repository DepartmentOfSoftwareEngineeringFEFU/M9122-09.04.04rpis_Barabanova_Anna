import click

from app import db
from app.commands import commands_bp
from app.models import Role, User
import sqlalchemy as sa


@commands_bp.cli.command("create-role")
@click.argument("label")
@click.argument("name")
@click.argument("is_admin", default=False)
def create_role(name, label, is_admin):
    if db.session.scalar(sa.select(Role).where(Role.label == label)):
        click.echo("Роль с таким именем уже существует", err=True)
        return
    elif db.session.scalar(sa.select(Role).where(Role.name == name)):
        click.echo("Роль с таким тегом уже существует", err=True)
        return
    db.session.add(
        Role(
            name=name,
            label=label,
            is_admin=is_admin
        )
    )
    db.session.commit()


@commands_bp.cli.command("create-user")
@click.argument("email")
@click.argument("password")
@click.argument("role_name")
def create_user(email, password, role_name):
    if db.session.scalar(sa.select(User).where(User.email == email)):
        click.echo("Пользователь с таким email уже существует", err=True)
        return
    role = db.session.scalar(sa.select(Role).where(Role.name == role_name))
    if not role:
        click.echo("Роль с таким тегом не существует", err=True)
        return
    user = User(email=email)
    user.roles.append(role)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
