from flask import Blueprint

commands_bp = Blueprint('commands', __name__, cli_group=None)

from .commands import *
