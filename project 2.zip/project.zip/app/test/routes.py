from flask import render_template, redirect, url_for
from flask_login import current_user, login_required
from flask_user import roles_required

from app.test import test_bp
from app.utils.forms import CreateForm, EditForm, DeleteForm, AnswerForm
from app import db
from app.models import Test, UserTestAssociation
import sqlalchemy as sa


@test_bp.route('/', methods=['GET'])
@login_required
def index():
    return render_template(
        f'test/base.html', is_admin=current_user.role.is_admin,
        tests=db.session.scalars(sa.select(Test)),
        user=current_user
    )


@test_bp.route('/create', methods=['GET', 'POST'])
@login_required
@roles_required('teacher')
def create():
    form = CreateForm()
    if form.validate_on_submit():
        db.session.add(
            Test(
                name=form.title.data,
                description=form.description.data
            )
        )
        db.session.commit()
        return redirect(url_for('test.index'))
    return render_template(
        f'test/create.html', is_admin=current_user.role.is_admin,
        form=form
    )


@test_bp.route('/view/<test_id>', methods=['GET', 'POST'])
@login_required
def view(test_id):
    finished_test = db.session.scalar(
        sa.select(UserTestAssociation)
        .where(UserTestAssociation.test_id == test_id, UserTestAssociation.user_id == current_user.id)
    )
    test: Test = db.session.scalar(sa.select(Test).where(Test.id == test_id))
    if not test or finished_test:
        return redirect(url_for('test.index'))
    e_form = EditForm()
    d_form = DeleteForm()
    s_form = AnswerForm()
    if e_form.validate_on_submit():
        test.name = e_form.title.data
        test.description = e_form.description.data
        db.session.commit()
        return redirect(url_for('test.index'))
    if d_form.validate_on_submit():
        db.session.delete(test)
        db.session.commit()
        return redirect(url_for('test.index'))
    if s_form.validate_on_submit():
        db.session.add(
            UserTestAssociation(
                user=current_user,
                test=test,
                solution=s_form.solution.data
            )
        )
        db.session.commit()
        return redirect(url_for('test.index'))
    e_form.title.data = test.name
    e_form.description.data = test.description
    d_form.id.data = test.id
    return render_template(
        f'test/single.html', is_admin=current_user.role.is_admin,
        e_form=e_form, d_form=d_form, s_form=s_form
    )


# @test_bp.route('/list', methods=['GET'])
# @login_required
# def test():
#     return jsonify(tuple(map(
#         lambda test: {'id': test.id, 'title': test.name, 'content': test.description},
#         db.session.scalars(sa.select(test))
#     )))