from flask import Flask

from .config import Config
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy


# Инициализация базы данных
db = SQLAlchemy()
migrate = Migrate()


def create_app():
    app = Flask(__name__)
    app.config['DEBUG'] = True
    app.config.from_object(Config)
    app.config['DEBUG'] = True

    db.init_app(app)
    migrate.init_app(app, db)

    from app.auth import auth_bp, MyUserManager
    app.register_blueprint(auth_bp)
    from app.main import main_bp
    app.register_blueprint(main_bp)
    from app.commands import commands_bp
    app.register_blueprint(commands_bp)
    from app.lecture import lecture_bp
    app.register_blueprint(lecture_bp)
    from app.task import task_bp
    app.register_blueprint(task_bp)
    from app.test import test_bp
    app.register_blueprint(test_bp)
    from app.giga_test import giga_test_bp
    app.register_blueprint(giga_test_bp)
    from app.check import check_bp
    app.register_blueprint(check_bp)

    from app.models import User
    user_manager = MyUserManager(app, db, User)
    user_manager.login_manager.login_view = 'auth.login'

    @app.context_processor
    def context_processor():
        return dict(user_manager=user_manager)
    return app


from app import models
app = create_app()