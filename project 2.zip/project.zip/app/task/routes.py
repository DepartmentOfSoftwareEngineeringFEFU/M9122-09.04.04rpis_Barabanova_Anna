from flask import render_template, redirect, url_for, request
from flask_login import current_user, login_required
from flask_user import roles_required

from app.task import task_bp
from app.utils.forms import CreateForm, EditForm, DeleteForm
from app import db
from app.models import Task
import sqlalchemy as sa


@task_bp.route('/', methods=['GET'])
@login_required
def index():
    return render_template(
        f'task/base.html', is_admin=current_user.role.is_admin,
        tasks=db.session.scalars(sa.select(Task))
    )


@task_bp.route('/create', methods=['GET', 'POST'])
@login_required
@roles_required('teacher')
def create():
    form = CreateForm()
    if form.validate_on_submit():
        db.session.add(
            Task(
                name=form.title.data,
                description=form.description.data
            )
        )
        db.session.commit()
        return redirect(url_for('task.index'))
    return render_template(
        f'task/create.html', is_admin=current_user.role.is_admin,
        form=form
    )


@task_bp.route('/view/<task_id>', methods=['GET', 'POST'])
@login_required
def view(task_id):
    task: Task = db.session.scalar(sa.select(Task).where(Task.id == task_id))
    if request.method == 'POST' and not current_user.role.is_admin or not task:
        return redirect(url_for('task.index'))
    e_form = EditForm()
    d_form = DeleteForm()
    if e_form.validate_on_submit():
        task.name = e_form.title.data
        task.description = e_form.description.data
        db.session.commit()
        return redirect(url_for('task.index'))
    if d_form.validate_on_submit():
        db.session.delete(task)
        db.session.commit()
        return redirect(url_for('task.index'))
    e_form.title.data = task.name
    e_form.description.data = task.description
    d_form.id.data = task.id
    return render_template(
        f'task/single.html', is_admin=current_user.role.is_admin,
        e_form=e_form, d_form=d_form
    )


# @task_bp.route('/list', methods=['GET'])
# @login_required
# def task():
#     return jsonify(tuple(map(
#         lambda task: {'id': task.id, 'title': task.name, 'content': task.description},
#         db.session.scalars(sa.select(task))
#     )))