from wtforms import HiddenField, StringField, TextAreaField, SubmitField
from wtforms.validators import DataRequired
from flask_wtf import FlaskForm


class CreateTask(FlaskForm):
    title = StringField('', validators=[DataRequired()], render_kw={'placeholder': 'Название задания'})
    description = TextAreaField('', validators=[DataRequired()], render_kw={'placeholder': 'Описание задания'})
    submit = SubmitField('Создать')


class EditTask(FlaskForm):
    id = HiddenField()
    title = StringField('', validators=[DataRequired()])
    description = TextAreaField('', validators=[DataRequired()])
    submit = SubmitField('Изменить')


class DeleteTask(FlaskForm):
    id = HiddenField()
    submit = SubmitField('Удалить')
