from wtforms import HiddenField, StringField, TextAreaField, SubmitField
from wtforms.validators import DataRequired
from flask_wtf import FlaskForm


class CreateForm(FlaskForm):
    title = StringField('', validators=[DataRequired()])
    description = TextAreaField('', validators=[DataRequired()])
    submit = SubmitField('Создать')


class EditForm(FlaskForm):
    title = StringField('', validators=[DataRequired()])
    description = TextAreaField('', validators=[DataRequired()])
    submit = SubmitField('Изменить')


class DeleteForm(FlaskForm):
    id = HiddenField(validators=[DataRequired()])
    submit = SubmitField('Удалить')


class AnswerForm(FlaskForm):
    solution = TextAreaField('', validators=[DataRequired()])
    submit = SubmitField('Отправить решение')
