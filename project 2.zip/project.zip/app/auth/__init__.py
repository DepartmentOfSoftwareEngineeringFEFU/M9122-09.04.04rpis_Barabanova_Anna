from flask import Blueprint
from flask_user import UserManager
from werkzeug.security import check_password_hash, generate_password_hash

auth_bp = Blueprint('auth', __name__)

from app.auth import routes


class MyUserManager(UserManager):
    def hash_password(self, password):
        return generate_password_hash(password)

    def verify_password(self, password, password_hash):
        return check_password_hash(password_hash, password)
