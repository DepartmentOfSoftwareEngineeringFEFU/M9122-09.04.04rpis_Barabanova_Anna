from flask import render_template, redirect, url_for
from flask_login import current_user, login_required
from flask_user import roles_required
from owlapy.class_expression import OWLDataHasValue
from owlapy.iri import IRI
from owlapy.owl_literal import OWLLiteral, DoubleOWLDatatype
from owlapy.owl_property import OWLDataProperty

from app.check import check_bp, sync_reasoner
from app.check.forms import MarkForm, TheoryForm
from app import db
from app.models import UserGigaTestAssociation, UserTestAssociation
import sqlalchemy as sa


@check_bp.route('/', methods=['GET', 'POST'])
@login_required
def index():
    solutions = []
    for solution in db.session.scalars(sa.select(UserGigaTestAssociation).where(UserGigaTestAssociation.mark == None)):
        solutions.append({
            's_id': solution.giga_test.id,
            'u_id': solution.user.id,
            'type': 'giga_test',
            'title': solution.giga_test.name,
            'user': solution.user.email
        })
    for solution in db.session.scalars(sa.select(UserTestAssociation).where(UserTestAssociation.mark == None)):

        solutions.append({
            's_id': solution.test.id,
            'u_id': solution.user.id,
            'type': 'test',
            'title': solution.test.name,
            'user': solution.user.email
        })
    form = TheoryForm()
    result = ''
    if form.validate_on_submit():
        value = form.width.data * form.length.data * form.height.data
        result = next(sync_reasoner.super_classes(
            OWLDataHasValue(property=OWLDataProperty(
                IRI('http://www.semanticweb.org/alinachusova/ontologies/2022/1/AcousticsMethods#', 'Volume')),
                            value=OWLLiteral(value, type_=DoubleOWLDatatype))
        ), 'для данного помещения необходимо использовать геометрическую теорию' if value >= 900 else 'необходимо использовать статическую теорию')
    return render_template(
        f'check/base.html', is_admin=current_user.role.is_admin,
        solutions=solutions,
        user=current_user,
        form=form,
        result=result
    )


@check_bp.route('/test/<int:solution_id>/<int:user_id>', methods=['GET', 'POST'])
@login_required
@roles_required('teacher')
def view_test(solution_id, user_id):
    solution = db.session.scalar(
        sa.select(UserTestAssociation)
        .where(
            UserTestAssociation.test_id == solution_id,
            UserTestAssociation.user_id == user_id
        )
    )
    if not solution or solution.mark:
        return redirect(url_for('check.index'))
    form = MarkForm()
    if form.validate_on_submit():
        solution.mark = form.mark.data
        db.session.commit()
        return redirect(url_for('check.index'))
    return render_template(
        f'check/single.html', form=form, test=solution.test, solution=solution.solution
    )


@check_bp.route('/assignment/<int:solution_id>/<int:user_id>', methods=['GET', 'POST'])
@login_required
@roles_required('teacher')
def view_giga_test(solution_id, user_id):
    solution = db.session.scalar(
        sa.select(UserGigaTestAssociation)
        .where(
            UserGigaTestAssociation.giga_test_id == solution_id,
            UserGigaTestAssociation.user_id == user_id
        )
    )
    if not solution or solution.mark:
        return redirect(url_for('check.index'))
    form = MarkForm()
    if form.validate_on_submit():
        solution.mark = form.mark.data
        db.session.commit()
        return redirect(url_for('check.index'))
    return render_template(
        f'check/single.html', form=form, test=solution.giga_test, solution=solution.solution
    )

# @check_bp.route('/list', methods=['GET'])
# @login_required
# def check():
#     return jsonify(tuple(map(
#         lambda check: {'id': check.id, 'title': check.name, 'content': check.description},
#         db.session.scalars(sa.select(check))
#     )))