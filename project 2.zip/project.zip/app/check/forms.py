from wtforms import IntegerField, SubmitField
from wtforms.validators import DataRequired
from flask_wtf import FlaskForm


class MarkForm(FlaskForm):
    mark = IntegerField(validators=[DataRequired()], render_kw={'placeholder': 'Оценка'})
    submit = SubmitField('Оценить')


class TheoryForm(FlaskForm):
    height = IntegerField('Высота помещения (м):', validators=[DataRequired()])
    length = IntegerField('Длина (м):', validators=[DataRequired()])
    width = IntegerField('Ширина (м):', validators=[DataRequired()])
    submit = SubmitField('Проверить')
