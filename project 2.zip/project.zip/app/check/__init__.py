import os.path

from flask import Blueprint
from owlapy.iri import IRI
from owlapy.owl_ontology_manager import OntologyManager
from owlapy.owl_reasoner import SyncReasoner, BaseReasoner

check_bp = Blueprint('check', __name__, url_prefix='/check')
manager = OntologyManager()

onto = manager.load_ontology(IRI.create(f"file://{os.path.dirname(__file__)}/AcousticMethodsAndTasks.owl"))
sync_reasoner = SyncReasoner(onto, BaseReasoner.HERMIT)

from app.check import routes
