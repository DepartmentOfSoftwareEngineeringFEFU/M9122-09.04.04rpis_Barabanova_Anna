import os
basedir = os.path.abspath(os.path.dirname(__file__))


class Config(object):
    USER_ENABLE_EMAIL = False
    CSRF_ENABLED = True
    WTF_CSRF_SECRET_KEY = 'FJxBal14nM66_fEXAJ6YNWA-NcsHAjaM'
    SECRET_KEY = 'K0R0o8FQReJS6P1tgrx4d-4ZqfahGyio'

    SQLALCHEMY_DATABASE_URI = f'postgresql://' \
                              f'{os.environ.get("DB_USER")}:{os.environ.get("DB_PASS")}' \
                              f'@{os.environ.get("DB_HOST")}:{os.environ.get("DB_PORT")}/{os.environ.get("DB_NAME")}'
    SQLALCHEMY_TRACK_MODIFICATIONS = True
